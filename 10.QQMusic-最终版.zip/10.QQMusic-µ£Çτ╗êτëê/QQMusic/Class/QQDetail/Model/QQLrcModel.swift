//
//  QQLrcModel.swift
//  QQMusic
//
//  Created by 单车 on 2020/4/2.
//  Copyright © 2020 单车. All rights reserved.
//

import UIKit

class QQLrcModel: NSObject {
    var beginTime : TimeInterval = 0
    var endTime : TimeInterval = 0
    var lrcContent : String = ""
    
    
}
